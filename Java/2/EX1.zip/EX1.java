import java.util.*;
import java.io.*;

/**
 *
 * @author meeraalshamsi
 */
public class EX1 {

    /**
     * @param args the command line arguments
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        //Input and output files 
        Scanner input = new Scanner(new FileReader("EX1_input.txt"));
        FileWriter out = new FileWriter("EX1_output.txt");
        
        //Declaration 
        String name;
        //Assignment of variable 
        while(input.hasNext()) 
        {
            //open loop 
            name = input.next();
            if(checkNameValidation(name))
            {
                out.append(name+"\n");
            }
            else
            {
                out.append("Invalid Name\n");
            }
        }
        input.close(); //close input file
        out.close(); //close output file
    }

    public static boolean checkNameValidation(String name) 
    {
        char c;
        //for loop
        for(int i = 0; i < name.length(); i++) 
        {
            c = name.toLowerCase().charAt(i);
            //If statement
            if(c < 'A' || c > 'z')
            {
                return false; 
            }
        }
        return true; 
    }
}